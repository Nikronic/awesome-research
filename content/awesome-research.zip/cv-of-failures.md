# CV of Failures
Source: https://web.archive.org/web/20240225221808/https://veronikach.com/progress-reports/my-cv-of-failures/
Example: https://web.archive.org/web/20231211120654/https://veronikach.com/failure/shadow-cv/

Write it as a blog and put it as the first. or create another designated page in navbar 

From now on in this file, only list them in a raw mode, and make it as entries (similar to original CV) on the website.

