# Things You Are Allowed To Do, Academic Edition
By [Dr. Bastian Rieck](https://bastian.rieck.me/)

- [ ] create todo lists that you can do in three temporal levels, 3 months, 1 year, long run

Ref: https://bastian.rieck.me/blog/2021/things/
