# Things You are Allowed to Do Readme

Content:
1. [[seven-things-i-wish-i-had-done-during-my-phd]]
2. [[things-you-are-allowed-to-do-academic-edition]]
3. [[things-you're-allowed-to-do]]
