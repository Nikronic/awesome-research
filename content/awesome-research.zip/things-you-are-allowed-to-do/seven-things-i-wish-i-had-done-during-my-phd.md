# 7 Things I Wish I Had Done During My PhD

By [Dr Veronika CH](https://veronikach.com/)

Ref: https://veronikach.com/phd-advice/7-things-i-wish-i-had-done-during-my-phd/
Alt: https://web.archive.org/web/20240102143601/https://veronikach.com/phd-advice/7-things-i-wish-i-had-done-during-my-phd/
