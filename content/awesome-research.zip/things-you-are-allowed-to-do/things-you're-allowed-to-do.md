# Things You're Allowed To Do
By [Milan Cvitkovic](https://milan.cvitkovic.net/)

Ref: https://milan.cvitkovic.net/writing/things_youre_allowed_to_do/