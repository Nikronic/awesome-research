*Rating are out of 5.*

## Index

| link | rating | content |
| ---- | ------ | --------- |
| https://discover.bme.utoronto.ca/how-to-approach-professors-when-applying-to-grad-school-part-1/ | 5 | contains info about the structure of email, content of email, don't and dos, and many other best practices. |
| https://lucklab.ucdavis.edu/blog/2018/9/17/emailing-faculty | 2 | structure of email, mentioning underrepresented/disadvantaged group in email, type of responses and what they mean |
| https://www.mcgill.ca/gradapplicants/research-supervision/connecting-supervisor | 3 | email content, questions to ask from corresponding students |
| https://www.science.org/content/article/dear-dr-neufeld | 5* | AWESOME! starts by an example, explains every bit of it, contains info about the font of email too :D |
| https://contemplativemammoth.com/2013/04/08/so-you-want-to-go-to-grad-school-nail-the-inquiry-email/ | 2 | content of email, lots of comments for review |
| https://www.ucl.ac.uk/taxome/jim/Mim/singer_grad_advice.htm | 4 | short yet very fun at other aspects of choosing uni, supervisor, and project |
| https://taylorinstitute.ucalgary.ca/sites/default/files/Content/Programs/PURE/20-TAY-PURE-Emailing-a-Potential-Research-Supervisor.pdf | 5* | full email template, explanation and norms |
| https://synapse.sa.utoronto.ca/2021/07/12/how-to-write-cold-emails-for-research-positions/ | 5 | everything
| https://3dpancakes.typepad.com/ernie/2009/12/reading-phd-applications.html | 5 | everything |
| https://www.ece.ucdavis.edu/~jowens/applying.html | 4 | no to generics, say ma name |

