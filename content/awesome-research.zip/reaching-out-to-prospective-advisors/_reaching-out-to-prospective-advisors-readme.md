# Reaching out to Prospective Advisors Readme

Content:
1. [[a-guide-to-cold-emailing-to-everyone]]
2. [[advice-on-contacting-faculty-for-prospective-research-students]]
3. [[cold-emails-contents]]
4. [[follow-up-for-cold-emails]]
5. [[information-about-emailing-professors]]
6. [[templating-method-for-cold-emailing-advisors]]
