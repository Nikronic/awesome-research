# Things You Should NOT Do Readme

Content:
1. [[avoid-a-miserable-phd]]
