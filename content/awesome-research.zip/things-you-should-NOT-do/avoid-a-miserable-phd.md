# Avoid "PhD students are miserable”

You can avoid this by:
- picking a supportive supervisor 
- not entering uncertain funding situations 
- only joining if it’s a subject you’re obsessed with 

>[!success]
>Don’t take a bad job, don’t join a bad PhD

---

>Also beware the urge to say “I’m built different,” in most cases you’re unfortunately not built different.
>![[GX7gi1KXMAAoAwA.jpg]]

>wonder if quitting a PhD should not be more normalized, I've seen a bunch of people who felt that not completing the PhD was a huge personal failure, whereas quitting another job is considered ok
>
> >It should be! If you quit a PhD, you got X years of time to learn and pick up new skills. Those are still there even if you quit and no one really cares besides you

Ref: https://x.com/EugeneVinitsky/status/1837145639043408290