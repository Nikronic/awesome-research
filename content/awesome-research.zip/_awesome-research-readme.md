# Awesome Research Readme

Content:
1. [[_grad-interviews-readme]]
2. [[_how-to-apply-readme]]
3. [[_how-to-do-research-readme]]
4. [[_how-to-pick-a-grad-school-readme]]
5. [[_reaching-out-to-prospective-advisors-readme]]
6. [[_things-you-are-allowed-to-do-readme]]
7. [[_things-you-should-not-do-readme]]
8. [[_understanding-grad-admission-readme]]
9. [[awesome-research-queue-items]]
