# Grad Interviews Readme

Content:
1. [[interview-with-a-professor]]

