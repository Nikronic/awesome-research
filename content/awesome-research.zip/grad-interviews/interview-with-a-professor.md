# Interview with a Professor

By [Hamed Akande](https://x.com/drhammed)

TBD

Ref: https://x.com/drhammed/status/1290287965625659393
