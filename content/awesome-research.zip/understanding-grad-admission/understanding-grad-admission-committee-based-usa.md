By [Yonatan Bisk](https://talkingtorobots.com/CLAW/)

TBD

Ref: https://talkingtorobots.com/FAQ.html

A part of [[information-about-emailing-professors|cold emailing advisors by Yonatan]].