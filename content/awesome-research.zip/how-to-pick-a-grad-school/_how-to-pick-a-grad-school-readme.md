# How to Pick a Grad School Readme

Content:
1. [[how-to-choose-your-grad-school]]
2. [[how-to-pick-a-grad-school-for-a-phd-in-computer-science]]
3. [[how-to-shortlist-advisors]]
4. [[questions-to-ask-a-prospective-advisor]]
