by [Bill Freeman](https://people.csail.mit.edu/billf/)

ref: https://people.csail.mit.edu/billf/talks/10minFreeman2013.pdf

---

![[10minFreeman2013.pdf]]
