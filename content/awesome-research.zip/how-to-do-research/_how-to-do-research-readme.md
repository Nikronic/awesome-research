# How to Do Research Readme

Content:
1. [[how-to-do-research]]
2. [[quality-for-success-in-graduate-school]]
