# Awesome Research Queue Items
1. My Speech to the Graduates: https://norvig.com/speech.html
2. Collection of Dave's Advice Collection: https://www.cs.virginia.edu/~evans/advice/
3. Meta Talk: How to Give a Talk So Good There Will Be Pizza Left for You: https://www.cs.virginia.edu/~evans/talks/metatalk/
4. How to Live in Paradise: A Guide for New and Disgruntled Professors: https://www.cs.virginia.edu/~evans/paradise/
